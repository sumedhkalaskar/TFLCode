using System;
using Xunit;

namespace TFLRoadStatus.e2e.Tests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

           
        }
    }
}
