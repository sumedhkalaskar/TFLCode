﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace TFLRoadStatus.UI
{
    public static class AppContainer
    {
        //var collection = new ServiceCollection();
        //readonly IServiceProvider serviceProvider;
        //public AppContainer()
        //{

        //}

        //collection.AddScoped<ISample1Service, Sample1Service>();  
    }
}
